<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-white">
        <div class="my-10">
            <div class="flex flex-col items-center mb-20">
                <div class="w-24 overflow-hidden mb-3">
                    <img src="<?php echo e(asset('/assets/icons/profile.svg')); ?>" alt="" class="min-w-full">
                </div>
                <h4 class="font-medium text-xl">
                    <?php if(auth()->user()->role == 1): ?>
                        GM
                    <?php endif; ?>
                    <?php echo e($user->username); ?>

                </h4>
                <h4 class="font-medium text-lg"><?php echo e($user->email); ?></h4>

                <?php if($user->id != auth()->user()->id): ?>
                    <form action="<?php echo e(route('user.toggle-follow', $user->id)); ?>" method="POST" class="my-5">
                        <?php echo csrf_field(); ?>
                        <?php if(!auth()->user()->followings()->where('users.id', $user->id)->exists()): ?>
                            <input type="submit" value="Follow" class="text-yellow-400 hover:underline-offset hover:cursor-pointer">
                        <?php else: ?>
                            <input type="submit" value="Unfollow" class="text-red-500 hover:underline-offset hover:cursor-pointer">
                        <?php endif; ?>
                    </form>
                <?php endif; ?>
            </div>

            <h1 class="font-bold text-2xl">Video User <?php echo e($user->username); ?></h1>

            <div class="grid grid-cols-3 gap-12 my-10">
                <?php $__empty_1 = true; $__currentLoopData = $user->videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('video.detail', $video->id)); ?>">
                        <div class="flex flex-col justify-stretch">
                            <div class="h-32 overflow-hidden bg-white mb-2">
                                <img src="<?php echo e(asset('/storage/uploads/thumbnails/' . $video->thumbnail)); ?>" alt="" class="min-h-full">
                            </div>
                            <h4 class="font-medium text-lg"><?php echo e($video->title); ?></h4>
                            <p class="font-thin text-sm text-gray-200"><?php echo e($video->user->username); ?></p>
                        </div>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Tidak ada data.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Joki\Gstation\resources\views/users/detail.blade.php ENDPATH**/ ?>
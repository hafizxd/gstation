<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-white mb-24">
        <div class="mb-5">
            <div class="h-96 flex justify-center bg-stone-700">
                <video controls class="h-full">
                    <source src="<?php echo e(asset('/storage/uploads/videos/' . $video->video)); ?>" type="video/mp4">
                    Your browser does not support the video tag.
                </video>
            </div>

            <div class="mt-8 flex justify-between items-center">
                <h1 class="text-3xl font-bold"><?php echo e($video->title); ?></h1>
                <div class="px-5">
                    <form action="<?php echo e(route('favorite.toggle', $video->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(!$video->favoritedBy()->where('users.id', auth()->user()->id)->exists()): ?>
                            <input type="submit" value="Tambahkan ke Favorit" class="bg-primary py-2 px-3 text-sm text-white hover:cursor-pointer">
                        <?php else: ?>
                            <input type="submit" value="Hapus dari Favorit" class="bg-red-500 py-2 px-3 text-sm text-white hover:cursor-pointer">
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <div class="mt-2 flex gap-3">
                <h6 class="text-md font-light text-gray-300"><?php echo e($video->user->username); ?></h6>
                <?php if($video->user->id != auth()->user()->id): ?>
                    <form action="<?php echo e(route('user.toggle-follow', $video->user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php if(!auth()->user()->followings()->where('users.id', $video->user->id)->exists()): ?>
                            <input type="submit" value="Follow" class="text-yellow-400 hover:underline-offset hover:cursor-pointer">
                        <?php else: ?>
                            <input type="submit" value="Unfollow" class="text-red-500 hover:underline-offset hover:cursor-pointer">
                        <?php endif; ?>
                    </form>
                <?php endif; ?>
            </div>

            <p class="mt-5 text-sm font-extralight text-gray-300"><?php echo e($video->description); ?></p>
        </div>


        <hr class="my-10">

        <div class="flex justify-center">
            <form action="<?php echo e(route('video.destroy-by-admin', $video->id)); ?>" method="POST" class="w-96 flex flex-col justify-center">
                <h1 class="text-center mb-5 text-lg">Hapus Video</h1>

                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>

                
                <div class="mb-5">
                    <div class="p-0 flex bg-cgray text-black">
                        <textarea id="reason" name="reason" rows="5" placeholder="Masukkan Alasan" required class="border-none bg-transparent m-0 w-full h-full focus:border-none focus:outline-none focus:ring-0 placeholder-slate-600"><?php echo e(old('description')); ?></textarea>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('reason'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('reason')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                </div>

                <input type="submit" value="Kirim Alasan & Hapus" class="bg-red-500 py-2 px-3 text-sm text-white hover:cursor-pointer">
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Projects\Joki\Gstation\resources\views/videos/detail.blade.php ENDPATH**/ ?>